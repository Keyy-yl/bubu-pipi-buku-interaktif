BUKU INTERAKTIF BUBU & PIPI

1. Ekstrak ZIP.
2. Buka folder hasil ekstrak di VS Code.
3. Klik kanan index.html > Open with Live Server.
4. Video masukkan ke assets/videos dengan nama scene-01.mp4 sampai scene-10.mp4.

Desain ini memakai sampul buku 3D dan dua halaman berdampingan. Tombol panah di sisi buku atau tombol “Balik Halaman” untuk pindah cerita. Tombol “Tutup Buku” kembali ke sampul.

Autoplay mencoba suara terlebih dahulu. Browser mungkin memblokir autoplay bersuara; jika demikian video mencoba berjalan tanpa suara dan menyediakan tombol “Putar dengan suara”.
Unggah seluruh isi folder ke GitHub untuk memakai GitHub Pages.
